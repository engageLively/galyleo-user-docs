Usage
=====

.. toctree::
   :maxdepth: 1

   adding_tables
   adding_filters
   creating_views
   creating_charts
   images_shapes_text
   publishing_dashboards