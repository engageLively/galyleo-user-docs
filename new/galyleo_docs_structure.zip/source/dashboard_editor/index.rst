Dashboard Editor
================

.. toctree::
   :maxdepth: 1

   overview
   top_bar
   halo
   context_menu