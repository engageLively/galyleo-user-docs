Data Architecture
=================

.. toctree::
   :maxdepth: 1

   Galyleo and the Simple Data Transfer Protocol
   tables
   filters
   views
   charts